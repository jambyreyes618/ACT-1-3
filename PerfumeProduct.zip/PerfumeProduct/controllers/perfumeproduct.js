/*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
import { Perfumeproduct, sequelize } from "../models/Perfumeproduct.js";

// Optional: Ilagay sa try-catch para safe ang sync kung minsan
try {
  await sequelize.sync();
} catch (err) {
  console.error("Database sync error:", err);
}

const perfumeproduct = {
  index: async (req, res) => {
    try {
      const data = await Perfumeproduct.findAll();
      res.render("perfumeproduct", { data });
    } catch (error) {
      console.error(error);
      res.status(500).send("Error loading products");
    }
  },

  insert: async (req, res) => {
    try {
      const { PerfumeName, ScentCategory, Size, Price, Quantity } = req.body;
      
      // I-save sa database gamit ang Sequelize
      const data = await Perfumeproduct.create({ 
        PerfumeName, 
        ScentCategory, 
        Size, 
        Price, 
        Quantity 
      });

      const isJson = req.headers["content-type"]?.includes("application/json");
      if (isJson) {
        return res.json(data);
      }
      res.redirect("/perfumeproduct");
    } catch (error) {
      console.error("Error inserting data:", error);
      res.status(500).send("Failed to add perfume: " + error.message);
    }
  },

  get: async (req, res) => {
    try {
      const data = await Perfumeproduct.findAll();
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },

  show: async (req, res) => {
    try {
      const { id } = req.params;
      const data = await Perfumeproduct.findByPk(id);
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },

  update: async (req, res) => {
    try {
      const { id } = req.params;
      // ITAMA ANG TYPO DITO: PefumeName -> PerfumeName
      const { PerfumeName, ScentCategory, Size, Price, Quantity } = req.body;

      await Perfumeproduct.update(
        { PerfumeName, ScentCategory, Size, Price, Quantity },
        { where: { id } }
      );

      const updatedData = await Perfumeproduct.findByPk(id);
      const isJson = req.headers["content-type"]?.includes("application/json");
      if (isJson) {
        return res.json(updatedData);
      }
      res.redirect("/perfumeproduct");
    } catch (error) {
      console.error("Error updating data:", error);
      res.status(500).send("Failed to update perfume: " + error.message);
    }
  },

  delete: async (req, res) => {
    try {
      const { id } = req.params;
      await Perfumeproduct.destroy({ where: { id } });

      const isJson = req.headers["content-type"]?.includes("application/json");
      if (isJson) {
        return res.json({ message: "Deleted successfully" });
      }
      res.redirect("/perfumeproduct");
    } catch (error) {
      console.error("Error deleting data:", error);
      res.status(500).send("Failed to delete perfume");
    }
  },
  
  editForm: async (req, res) => {
    try {
      const { id } = req.params;
      const perfumeproduct = await Perfumeproduct.findByPk(id);
      res.render("edit", { perfumeproduct });
    } catch (error) {
      res.status(500).send("Error loading edit form");
    }
  },
};

export { perfumeproduct };